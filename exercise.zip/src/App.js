import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import StepperComponent from "./component/Stepper";

function App() {
  return (
    <div className="App">
        <StepperComponent />
    </div>
  );
}

export default App;

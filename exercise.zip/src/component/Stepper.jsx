import React, { Component } from 'react';
import Stepper from '@material-ui/core/Stepper';
import Step from '@material-ui/core/Step';
import StepLabel from '@material-ui/core/StepLabel';
import StepContent from '@material-ui/core/StepContent';
import Paper from '@material-ui/core/Paper';
import Typography from '@material-ui/core/Typography';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

export default class StepperComponent extends Component {
    constructor(props){
        super(props);
        this.state = {
            activeStep :0,
        }
    }
    getSteps = ()=>{
        return ['Examination', 'Clinical History', 'Technique', 'Findings', 'Impressions'];
    }


     handleNext = (e) => {
        e.target.style.height = 'inherit';
        e.target.style.height = `${e.target.scrollHeight}px`; 
        let target = e.currentTarget.tabIndex  || 0;
        this.setState({
            activeStep:target
        })
    };
  
     setValues = (e) =>{
        var element = e.target;

        element.style.overflow = 'hidden';
        element.style.height = 0;
        element.style.height = element.scrollHeight + 'px';
       this.setState({
              [e.target.name] : e.target.value
       })
    }
  
  
    handleReset = () => {
       this.setState({
            activeStep:0
       })
    };

    handleSubmit = ()=>{
        var payload = [];
        var obj = {};

       // ['examination', 'clinicalHistory', 'technique', 'findings', 'impressions']
        obj.examination = this.state.examination;
        obj.clinicalHistory = this.state.clinicalHistory;
        obj.technique = this.state.technique;
        obj.findings = this.state.findings;
        obj.impressions = this.state.impressions;

        payload.push(obj);
        console.table(payload);
        console.log(payload);
        toast.success("Your report has been successfully submitted");
  
       
    }

    setStepContent = (step: number)=> {
        switch (step) {
          case 0:
            return <textarea type="text" 
                        className="form-control" 
                        name="examination" 
                        tabIndex="1" 
                        aria-describedby="Examination"
                        onBlur={this.handleNext}
                        onChange={this.setValues} 
                        rows="1"/>;
          case 1:
            return <textarea type="text" 
                        className="form-control" 
                        name="clinicalHistory" 
                        tabIndex="2" 
                        aria-describedby="Clinical History"
                        onBlur={this.handleNext}
                        onChange={this.setValues}
                        rows="1"/>;
          case 2:
              return <textarea type="text" 
                            className="form-control" 
                            name="technique" 
                            tabIndex="3" 
                            aria-describedby="Technique"
                            onBlur={this.handleNext}
                            onChange={this.setValues}
                            rows="1"/>;
          case 3:
              return <textarea type="text" 
                            className="form-control" 
                            name="findings" 
                            aria-describedby="Findings"
                            tabIndex="4" 
                            onBlur={this.handleNext}
                            onChange={this.setValues}
                            rows="1"/>;
          case 4:
               return <textarea type="text" 
                             className="form-control" 
                             name="impressions" 
                             aria-describedby="Impressions"
                             tabIndex="5" 
                             onBlur={this.handleNext}
                             onChange={this.setValues}
                             rows="1"/>;
         
          default:
            return 'Unknown step';
        }
      }

    render() {


        const steps = this.getSteps();



        

        return (
            <div className="form-container">
                 <ToastContainer position="top-right"
                    autoClose={3000}
                    hideProgressBar={false}
                    newestOnTop={false}
                    closeOnClick
                    rtl={false}
                    pauseOnFocusLoss
                    draggable
                    pauseOnHover/>
                <Stepper activeStep={this.state.activeStep} orientation="vertical">
                    {steps.map((label, index) => (
                    <Step key={label} expanded={true}>
                        <StepLabel>{label}</StepLabel>
                        <StepContent>
                        <Typography>{this.setStepContent(index)}</Typography>
                         <div>
                            <div>
                           
                            
                            </div>
                        </div> 
                        </StepContent>
                    </Step>
                    ))}
                </Stepper>
                <div className="col-md-12">
          
                    <Paper square elevation={0}>
                        <button
                                variant="contained"
                                color="primary"
                                onClick={this.handleSubmit}
                                className="btn btn-primary float-right"
                                aria-describedby="Submit Button"
                            >
                                Submit
                            </button>
                        <button onClick={this.handleReset}  style={{"marginRight":"30px"}}
                                variant="contained"
                                color="secondary" 
                                aria-describedby="Reset Button"
                                className="btn btn-danger m-l-10 float-right">
                            Reset
                        </button>
                   
                    </Paper>
               
                </div>
            </div>
        )
    }
}
